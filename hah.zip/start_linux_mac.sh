#!/bin/sh
npm i && node ./src/index.js